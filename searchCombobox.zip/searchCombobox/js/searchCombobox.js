(function($) {
		$.widget("ui.searchCombobox", {
			
			_create: function() {
				var self = this;
				var select = this.element;
				
				var maxLength = 0;
				select.children().each(function() {
				   if ($(this).text().length > maxLength){
                   		maxLength = $(this).text().length;
                   }
				});
				
                
				var input = $('<input id="'+select.attr('name')+'SearchText" size="'+maxLength+'"/>')
					.insertAfter(select)
					.hide()
					.autocomplete({
						source: function(request, response) {
							var matcher = new RegExp(request.term, "i");
							response(select.children("option").map(function() {
								var text = $(this).text();
								if (this.value && (!request.term || matcher.test(text)))
									return {
										id: this.value,
										label: text.replace(new RegExp("(?![^&;]+;)(?!<[^<>]*)(" + $.ui.autocomplete.escapeRegex(request.term) + ")(?![^<>]*>)(?![^&;]+;)", "gi"), "<strong>$1</strong>"),
										value: text
									};
							}));
						},
						delay: 0,
						select: function(event, ui) {
							if (!ui.item) {
								// remove invalid value, as it didn't match anything
								$(this).val("");
								return false;
							}
							select.val(ui.item.id);
							select.show();
							select.focus();
							select.trigger('change');
		    				$(this).hide();
						}
					});
					
					
				$('<img src="searchCombobox/images/Search-icon.png" id="search'+select.attr("name")+'" style="padding-right:.3em;">')
					.insertAfter(input)
					.mouseover(function() {
  						$(this).css('cursor', 'pointer');
  					})
  					.mouseout(function() {
  						$(this).css('cursor', 'default');
  					})
					.click(function(){
						maxLength = 0;
						select.children().each(function() {
						   if ($(this).text().length > maxLength){
		                   		maxLength = $(this).text().length;
		                   }
						});
						input.attr("size", maxLength);
					    select.toggle();
				    	input.toggle();
				    	
				    	if( input.is(':visible') ) {
				    		input.focus();
				    	}
				    	
			    	});
			
			}
		});
})(jQuery);
